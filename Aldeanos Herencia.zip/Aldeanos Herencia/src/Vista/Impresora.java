package Vista;
public class Impresora{

    public Impresora() {

    }

    public void imprimir(String mensaje){
        System.out.println(mensaje + "\n");
    }

}