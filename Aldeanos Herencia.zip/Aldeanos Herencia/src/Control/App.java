package Control;

public class App {

  public static void main(String[] args) {
    new Control();
  }
}
